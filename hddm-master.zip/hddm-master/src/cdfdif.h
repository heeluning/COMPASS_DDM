double cdfdif(double t, int x, double *par, double *prob);
