hddm.models package
===================

Submodules
----------

hddm.models.base module
-----------------------

.. automodule:: hddm.models.base
   :members:
   :undoc-members:
   :show-inheritance:

hddm.models.hddm\_info module
-----------------------------

.. automodule:: hddm.models.hddm_info
   :members:
   :undoc-members:
   :show-inheritance:

hddm.models.hddm\_nn module
---------------------------

.. automodule:: hddm.models.hddm_nn
   :members:
   :undoc-members:
   :show-inheritance:

hddm.models.hddm\_nn\_regression module
---------------------------------------

.. automodule:: hddm.models.hddm_nn_regression
   :members:
   :undoc-members:
   :show-inheritance:

hddm.models.hddm\_nn\_rl module
-------------------------------

.. automodule:: hddm.models.hddm_nn_rl
   :members:
   :undoc-members:
   :show-inheritance:

hddm.models.hddm\_nn\_rl\_regression module
-------------------------------------------

.. automodule:: hddm.models.hddm_nn_rl_regression
   :members:
   :undoc-members:
   :show-inheritance:

hddm.models.hddm\_nn\_stimcoding module
---------------------------------------

.. automodule:: hddm.models.hddm_nn_stimcoding
   :members:
   :undoc-members:
   :show-inheritance:

hddm.models.hddm\_regression module
-----------------------------------

.. automodule:: hddm.models.hddm_regression
   :members:
   :undoc-members:
   :show-inheritance:

hddm.models.hddm\_rl module
---------------------------

.. automodule:: hddm.models.hddm_rl
   :members:
   :undoc-members:
   :show-inheritance:

hddm.models.hddm\_rl\_regression module
---------------------------------------

.. automodule:: hddm.models.hddm_rl_regression
   :members:
   :undoc-members:
   :show-inheritance:

hddm.models.hddm\_stimcoding module
-----------------------------------

.. automodule:: hddm.models.hddm_stimcoding
   :members:
   :undoc-members:
   :show-inheritance:

hddm.models.hddm\_transformed module
------------------------------------

.. automodule:: hddm.models.hddm_transformed
   :members:
   :undoc-members:
   :show-inheritance:

hddm.models.hddm\_truncated module
----------------------------------

.. automodule:: hddm.models.hddm_truncated
   :members:
   :undoc-members:
   :show-inheritance:

hddm.models.rl module
---------------------

.. automodule:: hddm.models.rl
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: hddm.models
   :members:
   :undoc-members:
   :show-inheritance:
