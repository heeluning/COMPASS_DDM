hddm.torch package
==================

Submodules
----------

hddm.torch.mlp\_inference\_class module
---------------------------------------

.. automodule:: hddm.torch.mlp_inference_class
   :members:
   :undoc-members:
   :show-inheritance:

hddm.torch.mlp\_model\_class module
-----------------------------------

.. automodule:: hddm.torch.mlp_model_class
   :members:
   :undoc-members:
   :show-inheritance:

hddm.torch.torch\_config module
-------------------------------

.. automodule:: hddm.torch.torch_config
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: hddm.torch
   :members:
   :undoc-members:
   :show-inheritance:
